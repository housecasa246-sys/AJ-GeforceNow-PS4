#pragma once
#include "stream_settings.hpp"
#include <string>
#include <string_view>

namespace opennow::community_proxy
{
// Compatibility with older settings: this build always connects directly.
inline bool IsCommunityProxyUrl(std::string_view) { return false; }
inline std::string EnabledUrl(const StreamSettings&) { return {}; }
} // namespace opennow::community_proxy
