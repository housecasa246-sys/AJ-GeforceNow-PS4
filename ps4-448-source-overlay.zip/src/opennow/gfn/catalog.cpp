#include "internal.hpp"
#include "library_parser.hpp"
#include "../stream_startup_diagnostics.hpp"
#include "../trace_detail.hpp"

#include "../community_proxy_policy.hpp"
#include "../play_history.hpp"
#include "../server_location_policy.hpp"
#include "../stream_settings.hpp"

#include <algorithm>
#include <cctype>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace opennow
{
using namespace gfn::detail;

namespace
{
constexpr const char* kServiceUrlsEndpoint = "https://pcs.geforcenow.com/v1/serviceUrls";
constexpr const char* kPublicCatalogEndpoint =
    "https://static.nvidiagrid.net/supported-public-game-list/locales/gfnpc-en-US.json";
constexpr const char* kGraphQlEndpoint     = "https://games.geforce.com/graphql";
constexpr const char* kClientVersion       = "2.0.80.173";
constexpr const char* kLcarsClientId       = "ec7e38d4-03af-4b58-b131-cfb0495903ab";
constexpr const char* kDefaultLocale       = "en_US";
constexpr const char* kPanelsQueryHash = "f8e26265a5db5c20e1334a6872cf04b6e3970507697f6ae55a6ddefa5420daf0";
constexpr const char* kLibraryWithTimeQueryHash = "039e8c0d553972975485fee56e59f2549d2fdb518e247a42ab5022056a74406f";
constexpr const char* kPlayOrigin          = "https://play.geforcenow.com";
constexpr const char* kPlayReferer         = "https://play.geforcenow.com/";
constexpr std::size_t kCatalogPageSize = 60;
constexpr std::size_t kCatalogPageBytes = 4 * 1024 * 1024;

std::vector<std::string> BuildGfnLcarsHeaders(
    const std::string& token,
    const std::string& client_type,
    const std::string& client_streamer,
    bool include_user_agent)
{
    std::vector<std::string> headers;
    headers.push_back("Accept: application/json");
    headers.push_back("nv-client-id: " + std::string(kLcarsClientId));
    headers.push_back("nv-client-type: " + client_type);
    headers.push_back("nv-client-version: " + std::string(kClientVersion));
    headers.push_back("nv-client-streamer: " + client_streamer);
    headers.push_back("nv-device-os: WINDOWS");
    headers.push_back("nv-device-type: DESKTOP");

    if (!token.empty())
        headers.push_back("Authorization: GFNJWT " + token);

    if (include_user_agent)
        headers.push_back("User-Agent: " + std::string(GfnClient::kUserAgent));

    return headers;
}

std::vector<std::string> BuildGraphQlHeaders(const std::string& token)
{
    std::vector<std::string> headers;
    headers.push_back("Accept: application/json, text/plain, */*");
    // NVIDIA's Switch-facing persisted-query endpoint rejects this GET as
    // malformed JSON. application/graphql keeps both library and play-time
    // fields available while preserving the endpoint's expected request type.
    headers.push_back("Content-Type: application/graphql");
    headers.push_back("Origin: " + std::string(kPlayOrigin));
    headers.push_back("Referer: " + std::string(kPlayReferer));
    headers.push_back("nv-client-id: " + std::string(kLcarsClientId));
    headers.push_back("nv-client-type: NATIVE");
    headers.push_back("nv-client-version: " + std::string(kClientVersion));
    headers.push_back("nv-client-streamer: NVIDIA-CLASSIC");
    headers.push_back("nv-device-os: WINDOWS");
    headers.push_back("nv-device-type: DESKTOP");
    headers.push_back("nv-device-make: UNKNOWN");
    headers.push_back("nv-device-model: UNKNOWN");
    headers.push_back("nv-browser-type: CHROME");
    headers.push_back("User-Agent: " + std::string(GfnClient::kUserAgent));

    if (!token.empty())
        headers.push_back("Authorization: GFNJWT " + token);

    return headers;
}

// Log structure only: never account data, tokens, titles or response text.
void LogLibraryStructure(const HttpResponse& response, json_t* root, const char* attempt)
{
    std::string detail = std::string("attempt=") + attempt + " http=" +
        std::to_string(response.status_code) + " bytes=" + std::to_string(response.body.size());
    json_t* data = root ? json_object_get(root, "data") : nullptr;
    json_t* panels = data ? json_object_get(data, "panels") : nullptr;
    json_t* errors = root ? json_object_get(root, "errors") : nullptr;
    detail += " panels=" + std::to_string(json_is_array(panels) ? static_cast<int>(json_array_size(panels)) : -1);
    detail += " errors=" + std::to_string(json_is_array(errors) ? static_cast<int>(json_array_size(errors)) : -1);
    LogAppLifecycleEvent("LIBRARY_RESPONSE_STRUCTURE", detail.c_str());
    size_t pi; json_t* panel;
    json_array_foreach(panels, pi, panel) {
        if (pi >= 8) break;
        json_t* sections = json_object_get(panel, "sections");
        size_t si; json_t* section;
        json_array_foreach(sections, si, section) {
            if (si >= 8) break;
            json_t* items = json_object_get(section, "items");
            std::string d = "panel=" + std::to_string(pi) + " section=" + std::to_string(si) +
                " items=" + std::to_string(json_is_array(items) ? static_cast<int>(json_array_size(items)) : -1);
            size_t ii; json_t* item;
            json_array_foreach(items, ii, item) {
                if (ii >= 4) break;
                std::string type = GetString(item, "__typename");
                if (type.size() > 48 || type.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_") != std::string::npos)
                    type = "redacted";
                json_t* app = json_object_get(item, "app");
                d += " type=" + type + " app=" + (json_is_object(app) ? "object" : "missing");
            }
            LogAppLifecycleEvent("LIBRARY_SECTION_STRUCTURE", d.c_str());
        }
    }
}

std::string BuildLibraryUrl(const std::string& vpc_id, bool with_library_time)
{
    const std::string variables =
        std::string("{\"vpcId\":\"") + vpc_id + "\",\"locale\":\"" + kDefaultLocale +
        "\",\"panelNames\":[\"LIBRARY\"]}";

    const std::string extensions =
        std::string("{\"persistedQuery\":{\"sha256Hash\":\"") +
        (with_library_time ? kLibraryWithTimeQueryHash : kPanelsQueryHash) + "\"}}";

    std::string url = std::string(kGraphQlEndpoint) + "?";
    url += "requestType=" + UrlEncode("panels/Library");
    url += "&extensions=" + UrlEncode(extensions);
    url += "&huId=" + UrlEncode(HexEncode(GenerateRandomBytes(8).data(), 8));
    url += "&variables=" + UrlEncode(variables);
    return url;
}

std::string ResolveVpcId(
    const HttpClient& http_client,
    const AuthSession& session,
    const std::string& proxy_url)
{
    const StreamSettings settings = LoadStreamSettings();
    const std::string streaming_base_url = server_location::ResolveStreamingBaseUrl(
        settings.region, session.provider.streaming_service_url);
    if (streaming_base_url.empty())
        return "GFN-PC";

    const HttpResponse response = http_client.Get(
        streaming_base_url + "v2/serverInfo",
        GfnClient::kUserAgent,
        BuildGfnLcarsHeaders(ResolveSessionJwt(session), "NATIVE", "NVIDIA-CLASSIC", true),
        proxy_url);

    if (response.status_code != 200)
        return "GFN-PC";

    JsonPtr root = LoadJson(response.body);
    json_t* request_status = json_object_get(root.get(), "requestStatus");
    const std::string server_id = GetString(request_status, "serverId");
    return server_id.empty() ? std::string("GFN-PC") : server_id;
}

PublicGame ToPublicGame(const GameInfo& source)
{
    PublicGame game;
    game.id                    = source.id;
    game.uuid                  = source.uuid;
    game.launch_app_id         = source.launch_app_id;
    game.title                 = source.title;
    game.publisher             = source.publisher;
    game.image_url             = source.image_url;
    game.membership_tier_label = source.membership_tier_label;
    game.is_in_library         = source.is_in_library;
    game.variants              = source.variants;

    if (source.selected_variant_index < source.variants.size())
        game.store = source.variants[source.selected_variant_index].store;
    if (game.store.empty() && !source.available_stores.empty())
        game.store = source.available_stores.front();
    if (game.store.empty())
        game.store = "Unknown";
    return game;
}

CatalogPage ParseCatalogPage(JsonPtr& root, const std::string& cursor)
{
    ThrowIfGraphQlFailed(root.get());
    CatalogPage page;

    json_t* data = json_object_get(root.get(), "data");
    json_t* apps = data ? json_object_get(data, "apps") : nullptr;
    json_t* items = apps ? json_object_get(apps, "items") : nullptr;
    if (!json_is_array(items))
        throw std::runtime_error("Catalog response is missing the games array");
    if (json_array_size(items) > kCatalogPageSize)
        throw std::runtime_error("Catalog response exceeds the requested page size");

    json_t* page_info = json_object_get(apps, "pageInfo");
    if (!json_is_object(page_info) ||
        !json_is_boolean(json_object_get(page_info, "hasNextPage")))
        throw std::runtime_error("Catalog response is missing pagination information");
    if (GetBool(page_info, "hasNextPage"))
    {
        const auto end_cursor = GetString(page_info, "endCursor");
        if (end_cursor.empty() || end_cursor == cursor)
            throw std::runtime_error("Catalog pagination did not advance");
        page.next_cursor = end_cursor;
    }
    json_t* total = json_object_get(page_info, "totalCount");
    if (json_is_integer(total) && json_integer_value(total) >= 0)
        page.total_count = static_cast<std::size_t>(json_integer_value(total));

    size_t index = 0;
    json_t* app = nullptr;
    json_array_foreach(items, index, app)
    {
        GameInfo parsed = ParseApp(app);
        if (!parsed.id.empty() && !parsed.title.empty())
            page.games.push_back(ToPublicGame(parsed));
    }
    return page;
}

std::string BuildCatalogRequestBody(
    const std::string& vpc_id, const std::string& search_query,
    const std::string& cursor)
{
    static const char* kBrowseQuery = R"GRAPHQL(
query GetFilterBrowseResults($vpcId: String!, $locale: String!, $sortString: String!, $fetchCount: Int!, $cursor: String!, $filters: AppFilterFields!) {
  apps(vpcId: $vpcId, language: $locale, orderBy: $sortString, first: $fetchCount, after: $cursor, filters: $filters) {
    numberReturned numberSupported
    pageInfo { hasNextPage endCursor totalCount }
    items {
      id title longDescription shortDescription publisherName
      images { KEY_ART GAME_BOX_ART TV_BANNER HERO_IMAGE }
      variants { id appStore gfn { status library { status selected } } }
      gfn { playabilityState minimumMembershipTierLabel }
    }
  }
})GRAPHQL";
    static const char* kSearchQuery = R"GRAPHQL(
query GetSearchFilterResults($vpcId: String!, $locale: String!, $sortString: String!, $fetchCount: Int!, $cursor: String!, $searchString: String!, $filters: AppFilterFields!) {
  apps(vpcId: $vpcId, language: $locale, orderBy: $sortString, first: $fetchCount, after: $cursor, searchQuery: $searchString, filters: $filters) {
    numberReturned numberSupported
    pageInfo { hasNextPage endCursor totalCount }
    items {
      id title longDescription shortDescription publisherName
      images { KEY_ART GAME_BOX_ART TV_BANNER HERO_IMAGE }
      variants { id appStore gfn { status library { status selected } } }
      gfn { playabilityState minimumMembershipTierLabel }
    }
  }
})GRAPHQL";

    JsonPtr body(json_object(), &json_decref);
    JsonPtr variables(json_object(), &json_decref);
    json_object_set_new(body.get(), "query", json_string(search_query.empty() ? kBrowseQuery : kSearchQuery));
    json_object_set_new(variables.get(), "vpcId", json_string(vpc_id.c_str()));
    json_object_set_new(variables.get(), "locale", json_string(kDefaultLocale));
    json_object_set_new(
        variables.get(), "sortString",
        json_string("itemMetadata.relevance:DESC,sortName:ASC"));
    json_object_set_new(variables.get(), "fetchCount", json_integer(kCatalogPageSize));
    json_object_set_new(variables.get(), "cursor", json_string(cursor.c_str()));
    json_object_set_new(variables.get(), "filters", json_object());
    if (!search_query.empty())
        json_object_set_new(variables.get(), "searchString", json_string(search_query.c_str()));
    json_object_set_new(body.get(), "variables", json_incref(variables.get()));
    return DumpJson(body.get());
}

std::vector<std::string> BuildGraphQlPostHeaders(const std::string& token)
{
    std::vector<std::string> headers = BuildGraphQlHeaders(token);
    for (std::string& header : headers)
    {
        if (header.find("Content-Type:") == 0)
            header = "Content-Type: application/json";
    }
    return headers;
}

std::string InferStore(json_t* item)
{
    const std::string explicit_store = GetString(item, "store");
    if (!explicit_store.empty())
        return explicit_store;

    const std::string publisher = GetString(item, "publisher");
    if (publisher.find("NCSoft") != std::string::npos ||
        publisher.find("ncsoft") != std::string::npos)
    {
        return "NCSoft";
    }

    return "Unknown";
}


} // namespace

std::vector<LoginProvider> GfnClient::FetchLoginProviders() const
{
    const HttpResponse response = http_client_.Get(
        kServiceUrlsEndpoint,
        kUserAgent,
        {"Accept: application/json"});

    if (response.status_code != 200)
    {
        throw std::runtime_error(
            "Provider discovery failed with HTTP " + std::to_string(response.status_code));
    }

    JsonPtr root = LoadJson(response.body);
    json_t* gfn_service_info =
        json_object_get(root.get(), "gfnServiceInfo");
    json_t* endpoints =
        gfn_service_info ? json_object_get(gfn_service_info, "gfnServiceEndpoints") : nullptr;

    std::vector<LoginProvider> providers;
    if (json_is_array(endpoints))
    {
        size_t index = 0;
        json_t* entry = nullptr;
        json_array_foreach(endpoints, index, entry)
        {
            LoginProvider provider;
            provider.idp_id                = GetString(entry, "idpId");
            provider.code                  = GetString(entry, "loginProviderCode");
            provider.display_name          = GetString(entry, "loginProviderDisplayName");
            provider.streaming_service_url = EnsureTrailingSlash(GetString(entry, "streamingServiceUrl"));
            provider.priority              = GetInteger(entry, "loginProviderPriority", 0);

            if (provider.code == "BPC")
                provider.display_name = "bro.game";

            if (!provider.idp_id.empty() && !provider.streaming_service_url.empty())
                providers.push_back(provider);
        }
    }

    if (providers.empty())
        providers.push_back(DefaultProvider());

    std::sort(
        providers.begin(),
        providers.end(),
        [](const LoginProvider& left, const LoginProvider& right) {
            return left.priority < right.priority;
        });

    return providers;
}

std::vector<PublicGame> GfnClient::FetchPublicGames() const
{
    const std::string proxy_url = community_proxy::EnabledUrl(LoadStreamSettings());
    const HttpResponse response = http_client_.Get(
        kPublicCatalogEndpoint,
        kUserAgent,
        {"Accept: application/json"},
        proxy_url);

    if (response.status_code != 200)
    {
        throw std::runtime_error(
            "Public catalog fetch failed with HTTP " + std::to_string(response.status_code));
    }

    JsonPtr root = LoadJson(response.body);
    if (!json_is_array(root.get()))
        throw std::runtime_error("Public catalog payload is not a JSON array");

    std::vector<PublicGame> games;

    size_t index = 0;
    json_t* item = nullptr;
    json_array_foreach(root.get(), index, item)
    {
        const std::string status = GetString(item, "status");
        const std::string title  = GetString(item, "title");
        if (status != "AVAILABLE" || title.empty())
            continue;

        PublicGame game;
        game.id        = GetString(item, "id");
        game.title     = title;
        game.store     = InferStore(item);
        game.publisher = GetString(item, "publisher");
        // Public entries have no NVIDIA artwork; use the local placeholder.
        if (game.id.empty())
            game.id = game.title;

        games.push_back(std::move(game));
    }

    std::sort(
        games.begin(),
        games.end(),
        [](const PublicGame& left, const PublicGame& right) {
            return left.title < right.title;
        });

    return games;
}

CatalogPage GfnClient::FetchCatalogPage(
    AuthSession& session, const std::string& search_query, const std::string& cursor) const
{
    const std::string vpc_id = ResolveCatalogVpcId(session);
    return FetchCatalogPage(session, search_query, cursor, vpc_id);
}

std::string GfnClient::ResolveCatalogVpcId(AuthSession& session) const
{
    session = RecoverSavedSession(session);
    const std::string proxy_url = community_proxy::EnabledUrl(LoadStreamSettings());
    return ResolveVpcId(http_client_, session, proxy_url);
}

CatalogPage GfnClient::FetchCatalogPage(
    AuthSession& session, const std::string& search_query,
    const std::string& cursor, const std::string& vpc_id) const
{
    session = RecoverSavedSession(session);
    std::string jwt_token = ResolveSessionJwt(session);
    const std::string proxy_url = community_proxy::EnabledUrl(LoadStreamSettings());

    HttpResponse response = http_client_.Post(
        kGraphQlEndpoint,
        kUserAgent,
        BuildGraphQlPostHeaders(jwt_token),
        BuildCatalogRequestBody(vpc_id, search_query, cursor),
        proxy_url, {.max_body_bytes = kCatalogPageBytes});

    if (response.status_code == 401)
    {
        session = RecoverSavedSession(session, true);
        jwt_token = ResolveSessionJwt(session);
        response = http_client_.Post(
            kGraphQlEndpoint,
            kUserAgent,
            BuildGraphQlPostHeaders(jwt_token),
            BuildCatalogRequestBody(vpc_id, search_query, cursor),
            proxy_url, {.max_body_bytes = kCatalogPageBytes});
    }

    if (response.status_code != 200)
    {
        throw std::runtime_error(
            "Catalog browse failed with HTTP " + std::to_string(response.status_code));
    }

    JsonPtr root = LoadJson(response.body);
    return ParseCatalogPage(root, cursor);
}
std::vector<GameInfo> GfnClient::FetchLibraryGames(AuthSession& session) const
{
    trace::BootStepSync("LIBRARY_AUTH_BEGIN", nullptr);
    session = RecoverSavedSession(session);
    trace::BootStepSync("LIBRARY_AUTH_END", nullptr);
    std::string jwt_token = ResolveSessionJwt(session);
    const std::string proxy_url = community_proxy::EnabledUrl(LoadStreamSettings());
    trace::BootStepSync("LIBRARY_VPC_BEGIN", nullptr);
    const std::string vpc_id = ResolveVpcId(http_client_, session, proxy_url);
    trace::BootStepSync("LIBRARY_VPC_END", nullptr);

    HttpResponse response = http_client_.Get(
        BuildLibraryUrl(vpc_id, true),
        kUserAgent,
        BuildGraphQlHeaders(jwt_token),
        proxy_url);

    LogAppLifecycleEvent("LIBRARY_QUERY_STATUS", ("attempt=with_time http=" + std::to_string(response.status_code)).c_str());
    if (response.status_code == 401)
    {
        session = RecoverSavedSession(session, true);
        jwt_token = ResolveSessionJwt(session);
        response = http_client_.Get(
            BuildLibraryUrl(vpc_id, true),
            kUserAgent,
            BuildGraphQlHeaders(jwt_token),
            proxy_url);
    }

    if (response.status_code != 200)
    {
        response = http_client_.Get(
            BuildLibraryUrl(vpc_id, false),
            kUserAgent,
            BuildGraphQlHeaders(jwt_token),
            proxy_url);
    }

    if (response.status_code != 200)
    {
        throw std::runtime_error(
            "Library fetch failed with HTTP " + std::to_string(response.status_code));
    }

    trace::BootStepSync("LIBRARY_JSON_BEGIN", nullptr);
    JsonPtr root = LoadJson(response.body);
    trace::BootStepSync("LIBRARY_JSON_END", nullptr);
    LogLibraryStructure(response, root.get(), "selected");
    trace::BootStepSync("LIBRARY_ITEMS_BEGIN", nullptr);
    std::vector<GameInfo> games = ParseLibraryGames(root);
    trace::BootStepSync("LIBRARY_ITEMS_END", nullptr);
    ApplyPlayHistory(games, LoadPlayHistory());
    return games;
}

} // namespace opennow
