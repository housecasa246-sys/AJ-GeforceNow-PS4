#include "../src/opennow/ps4_catalog_file_info.hpp"
#include <cassert>
#include <cstdio>
#include <cstring>
int main() {
    using namespace opennow::catalog_file;
    // Construct a kernel reply by wire offsets, independently of field access.
    unsigned char wire[120]{};
    std::uint16_t mode = 0100644;
    std::int64_t timestamp = 1700000000, size = 36280;
    std::memcpy(wire + 8, &mode, 2);
    std::memcpy(wire + 40, &timestamp, 8);
    std::memcpy(wire + 72, &size, 8);
    NativeStat info{};
    std::memcpy(&info, wire, sizeof info);
    assert(info.size == size && info.modified.seconds == timestamp);
    assert(IsFresh(info, timestamp + 60));
    assert(!IsFresh(info, timestamp + 86401));
    assert(!IsFresh(info, timestamp - 301));
    info.size = 0; assert(!IsFresh(info, timestamp));
    info.size = 4 * 1024 * 1024 + 1; assert(!IsFresh(info, timestamp));
    info.size = 10; info.mode = 0040755; assert(!IsFresh(info, timestamp));
    std::puts("PASS: native stat offsets, fresh/expired/future/empty/oversize/directory cache");
}
