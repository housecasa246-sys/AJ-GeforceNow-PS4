# Build dependency provenance

The four generated Mbed TLS 3.4.0 library sources (error.c,
version_features.c, ssl_debug_helpers_generated.c and
psa_crypto_driver_wrappers.c) come unmodified from the official tag v3.4.0,
commit 1873d3bfc2da771672bd8e7e8f41f57e0af77f33:
https://github.com/Mbed-TLS/mbedtls/tree/1873d3bfc2da771672bd8e7e8f41f57e0af77f33/library
They allow the supported GEN_FILES=OFF build without host Perl/Jinja.
Their Apache-2.0 headers are retained.

zlib 1.3.1 is from https://zlib.net/fossils/zlib-1.3.1.tar.gz
SHA256: 9a93b2b7dfdac77ceba5a558a580e74667dd6fede4585b91eefb60f03b72df23
Its original README/license is retained. It is statically compiled for Orbis
and enables FFmpeg's PNG decoder, which was previously silently disabled.

OpenOrbis v0.5.3 compatibility declarations for Random and HTTP receive timeout
were checked against shadPS4's corresponding public library headers:
https://github.com/shadps4-emu/shadPS4/blob/main/src/core/libraries/random/random.h
https://github.com/shadps4-emu/shadPS4/blob/main/src/core/libraries/network/http.h
