# Conexiones directas y diagnóstico del catálogo

Este cambio parte de `87568ca50a89e6f8dd65fe005d21521c27e65c26`.
El PKG 4.39 que ya estaba en `build/` **no incluye estos cambios**.

## Cambios

- Eliminada la API y la implementación de aprovisionamiento del proxy comunitario.
- La configuración antigua del proxy se invalida al cargar/guardar; los consumidores
  reciben siempre una ruta directa, incluso con un objeto de configuración antiguo.
- Eliminadas las consultas accesorias a Gravatar, imágenes de Steam, Cloudflare
  Speed y STUN de Google. El botón de velocidad ahora comprueba conexión a NVIDIA;
  no presenta esa respuesta pequeña como una medición de ancho de banda.
- Se conservan OAuth por QR, los QR locales, CloudMatch, WebSocket, WebRTC, audio,
  vídeo, mando y los servidores ICE proporcionados por la sesión. Los proveedores
  regionales del servicio pueden utilizar dominios distintos de NVIDIA.

## Qué significaba HTTP 200

El código PS4 marcaba una biblioteca autenticada sin juegos como error `-22`, aun
  después de recibir correctamente la respuesta. La pantalla priorizaba cualquier
  código HTTP positivo, por lo que mostraba “NO SE PUDO CARGAR: HTTP 200”. Además,
  el analizador convertía una estructura sin `data.panels` en una lista vacía.

Ahora una biblioteca vacía válida se publica en la interfaz y muestra el estado
sin juegos. Los campos estructurales ausentes se rechazan explícitamente. Los
errores locales de parseo/memoria ya no se presentan como un error HTTP 200.
Las excepciones detalladas continúan en el registro `CATALOG_FAILED`.

Una consulta pública realizada durante este trabajo devolvió 200, 409039 bytes y
1550 entradas. Esto valida ese endpoint público, no la biblioteca de una cuenta.
El límite público de 2 MiB no fue la causa de esa respuesta; se conserva como
límite de memoria. Se solicita contenido sin compresión y se inicializa la marca
de vinculación de cada entrada pública.

No se ha reproducido la sesión del usuario en una PS4. No se garantiza que estas
causas expliquen todos sus fallos ni que el servicio acepte la sesión en su región.

## CI y comprobación

`.github/workflows/ps4-pkg.yml` usa Windows 2022 y OpenOrbis v0.5.3 LLVM 18.2,
LLVM-MinGW 20260922 y CMake 3.31.12 descargados desde sus proyectos oficiales.
Los ZIP se verifican con SHA-256. El ZIP de OpenOrbis contiene un tar.gz anidado.
Python y .NET 8 se preparan con las acciones oficiales; PkgTool usa compatibilidad
de runtime `DOTNET_ROLL_FORWARD=Major` porque declara .NET Core 3.0.

El flujo ejecuta pruebas de host, compila el código actual, ejecuta las auditorías
del proyecto y `pkg_validate`. Solo después publica el PKG de `build/ps4/`, con el
SHA del commit y el hash del archivo. Nunca recoge el PKG antiguo de `build/`.
Se puede iniciar por push, pull request o `workflow_dispatch`.

Las pruebas nuevas se ejecutan con:

```powershell
./scripts/run-host-tests.ps1
./scripts/test-library-response.ps1
```

La segunda compila Jansson para el PC y prueba el mismo analizador usado por el
cliente: biblioteca vacía, campos ausentes, errores GraphQL, HTML y juego válido.
Las pruebas de host no prueban la consola ni reemplazan una compilación completa.

## Estado de esta entrega

La versión 4.40 se compiló localmente con OpenOrbis. Se validaron la integridad
y firmas del PKG mediante PkgTool y las auditorías de binario/layout/navegación.
La suite de host pasó en la primera compilación; al repetirla tras añadir PNG,
Windows bloqueó video_row_swap_test.exe. El resto pasó. También pasó el analizador real de biblioteca.
Se incorporaron los archivos generados oficiales de Mbed TLS y zlib para PNG;
ver build-dependency-provenance.md.

La CI está preparada pero no se ejecutó en GitHub. La integración devuelve 403
al crear una rama y no existe autenticación Git utilizable; no se publicaron
cambios remotos. El código y el parche se entregan para aplicarlos al repositorio.

La consola todavía no se probó. Compilación e integridad no prueban que NVIDIA
acepte el inicio de sesión o que el streaming funcione en el firmware del usuario.
Para validar en consola: iniciar sesión con el QR, abrir una cuenta sin juegos,
abrir una con juegos vinculados, cambiar a TODOS, iniciar un juego, comprobar
audio/vídeo/mando y salir. Repetir con configuración antigua del proxy; no debe
contactar el servicio eliminado. Conservar los registros localmente: pueden
contener datos de sesión y no deben publicarse sin revisión.
