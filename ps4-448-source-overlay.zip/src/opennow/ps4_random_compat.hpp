#pragma once
#include <cstddef>
#include <cstdint>

// OpenOrbis v0.5.3 still ships a void(void) placeholder for this export.
// Declare the buffer/length ABI already used by this client, also documented at:
// https://github.com/shadps4-emu/shadPS4/blob/main/src/core/libraries/random/random.h
// Keep the 16-byte request limit and failure handling in ps4_secure_random.cpp.
extern "C" int sceRandomGetRandomNumber(std::uint8_t* buffer, std::size_t size);
