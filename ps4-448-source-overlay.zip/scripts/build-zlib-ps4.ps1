$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$cmake = Join-Path $root 'tools/cmake-3.31.12/cmake-3.31.12-windows-x86_64/bin/cmake.exe'
$build = Join-Path $root 'build/zlib-ps4'
$dist = Join-Path $root 'build/libpeer-ps4/dist'
& $cmake -S (Join-Path $root 'src/third_party/zlib-1.3.1') -B $build -G 'Unix Makefiles' `
    "-DCMAKE_TOOLCHAIN_FILE=$root/scripts/cmake/orbis-ps4-x64.cmake" `
    -DCMAKE_BUILD_TYPE=Release -DZLIB_BUILD_EXAMPLES=OFF
if ($LASTEXITCODE -ne 0) { throw 'zlib configure failed' }
& $cmake --build $build --target zlibstatic --parallel 3
if ($LASTEXITCODE -ne 0) { throw 'zlib build failed' }
New-Item -ItemType Directory -Force "$dist/lib","$dist/include" | Out-Null
Copy-Item "$build/libz.a" "$dist/lib/libz.a" -Force
Copy-Item "$build/zconf.h","$root/src/third_party/zlib-1.3.1/zlib.h" "$dist/include/" -Force
