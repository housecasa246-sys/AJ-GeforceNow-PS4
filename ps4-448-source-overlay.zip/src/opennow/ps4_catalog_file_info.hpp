#pragma once
#include <cstddef>
#include <cstdint>

namespace opennow::catalog_file {
// Native Orbis stat ABI. The bundled musl header uses a 32-bit mode_t,
// shifting timestamps and size by eight bytes. Do not pass that layout to
// the kernel. ABI reference: shadPS4 src/core/libraries/kernel/file_system.h.
struct Timespec { std::int64_t seconds, nanoseconds; };
struct NativeStat {
    std::uint32_t device, inode;
    std::uint16_t mode, links;
    std::uint32_t uid, gid, rdevice;
    Timespec accessed, modified, changed;
    std::int64_t size, blocks;
    std::uint32_t block_size, flags, generation, spare;
    Timespec created;
};
static_assert(sizeof(NativeStat) == 120);
static_assert(offsetof(NativeStat, modified) == 40);
static_assert(offsetof(NativeStat, size) == 72);
inline bool IsFresh(const NativeStat& info, std::int64_t now) {
    return (info.mode & 0170000) == 0100000 && info.size > 0 &&
        info.size <= 4 * 1024 * 1024 && now > 0 && info.modified.seconds > 0 &&
        info.modified.seconds <= now + 300 &&
        info.modified.seconds >= now - 24 * 60 * 60;
}
#ifdef __ORBIS__
extern "C" int NativeKernelStat(const char*, NativeStat*) __asm__("sceKernelStat");
#endif
}
