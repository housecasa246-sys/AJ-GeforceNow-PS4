#pragma once
#include <cstdio>
#include <string>

namespace opennow::catalog_result
{
// HTTP success and application/parse success are separate outcomes.
inline std::string ErrorMessage(int status, int error)
{
    if (status >= 300)
        return "NO SE PUDO CARGAR: HTTP " + std::to_string(status);
    if (error == -22)
        return "CATALOGO INVALIDO: RESPUESTA JSON NO COMPATIBLE";
    if (error == -12)
        return "CATALOGO INCOMPLETO: LIMITE DE MEMORIA";
    return "NO SE PUDO CARGAR: ERROR " + std::to_string(error);
}
} // namespace opennow::catalog_result
