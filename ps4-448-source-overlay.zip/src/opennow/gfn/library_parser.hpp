#pragma once
#include "internal.hpp"
#include <algorithm>
#include <cctype>
#include <unordered_map>
#include <stdexcept>

namespace opennow::gfn::detail
{
inline std::string OptimizeImageUrl(const std::string& url)
{
    if (url.find("img.nvidiagrid.net") != std::string::npos)
        return url + ";w=272";

    return url;
}

inline bool IsOwnedLibraryStatus(const std::string& status)
{
    return status == "MANUAL" || status == "PLATFORM_SYNC" || status == "IN_LIBRARY";
}

inline bool IsNumericId(const std::string& value)
{
    if (value.empty())
        return false;

    return std::all_of(value.begin(), value.end(), [](unsigned char ch) {
        return std::isdigit(ch) != 0;
    });
}

inline GameInfo ParseApp(json_t* app)
{
    GameInfo game;
    game.id                 = GetString(app, "id");
    game.uuid               = game.id;
    game.title              = GetString(app, "title");
    game.description        = GetString(app, "description");
    if (game.description.empty())
        game.description = GetString(app, "longDescription");
    if (game.description.empty())
        game.description = GetString(app, "shortDescription");
    game.publisher          = GetString(app, "publisherName");
    json_t* app_gfn = json_object_get(app, "gfn");
    game.membership_tier_label = GetString(app_gfn, "minimumMembershipTierLabel");
    json_t* app_library = app_gfn ? json_object_get(app_gfn, "library") : nullptr;
    game.last_played = GetString(app_library, "lastPlayedDate");
    if (game.last_played.empty())
        game.last_played = GetString(app_library, "lastPlayedAt");

    json_t* images = json_object_get(app, "images");
    for (const char* key : {"KEY_ART", "GAME_BOX_ART", "TV_BANNER", "HERO_IMAGE"})
    {
        const std::string candidate = GetString(images, key);
        if (!candidate.empty())
        {
            game.image_url = OptimizeImageUrl(candidate);
            break;
        }
    }

    json_t* variants = json_object_get(app, "variants");
    if (json_is_array(variants))
    {
        size_t index = 0;
        json_t* entry = nullptr;
        json_array_foreach(variants, index, entry)
        {
            GameVariant variant;
            variant.id    = GetString(entry, "id");
            variant.store = GetString(entry, "appStore");

            json_t* gfn = json_object_get(entry, "gfn");
            variant.gfn_status = GetString(gfn, "status");

            json_t* library = gfn ? json_object_get(gfn, "library") : nullptr;
            variant.library_status   = GetString(library, "status");
            variant.library_selected = GetBool(library, "selected");
            variant.last_played_date = GetString(library, "lastPlayedDate");
            if (variant.last_played_date.empty())
                variant.last_played_date = GetString(library, "lastPlayedAt");
            if (variant.last_played_date.empty())
                variant.last_played_date = GetString(library, "lastPlayed");

            if (variant.library_selected) {
                game.selected_variant_index = index;
                game.launch_app_id = variant.id;
            }

            if (!variant.last_played_date.empty() &&
                (game.last_played.empty() || variant.last_played_date > game.last_played))
                game.last_played = variant.last_played_date;

            if (!variant.store.empty() &&
                std::find(game.available_stores.begin(), game.available_stores.end(), variant.store) ==
                    game.available_stores.end())
            {
                game.available_stores.push_back(variant.store);
            }

            if (IsOwnedLibraryStatus(variant.library_status))
                game.is_in_library = true;

            if (game.launch_app_id.empty() && IsNumericId(variant.id))
                game.launch_app_id = variant.id;

            game.variants.push_back(std::move(variant));
        }
    }

    if (game.launch_app_id.empty() && IsNumericId(game.id))
        game.launch_app_id = game.id;

    return game;
}

inline void MergeGame(GameInfo& target, const GameInfo& incoming)
{
    if (target.image_url.empty())
        target.image_url = incoming.image_url;

    if (target.description.empty())
        target.description = incoming.description;

    if (target.publisher.empty())
        target.publisher = incoming.publisher;

    if (!incoming.last_played.empty() &&
        (target.last_played.empty() || incoming.last_played > target.last_played))
        target.last_played = incoming.last_played;

    if (target.launch_app_id.empty())
        target.launch_app_id = incoming.launch_app_id;

    if (target.membership_tier_label.empty())
        target.membership_tier_label = incoming.membership_tier_label;

    target.is_in_library = target.is_in_library || incoming.is_in_library;

    for (const auto& store : incoming.available_stores)
    {
        if (std::find(target.available_stores.begin(), target.available_stores.end(), store) ==
            target.available_stores.end())
        {
            target.available_stores.push_back(store);
        }
    }

    for (const auto& variant : incoming.variants)
    {
        const auto it = std::find_if(
            target.variants.begin(),
            target.variants.end(),
            [&variant](const GameVariant& existing) { return existing.id == variant.id; });

        if (it == target.variants.end())
            target.variants.push_back(variant);
    }
}

inline void ThrowIfGraphQlFailed(json_t* root)
{
    json_t* errors = root ? json_object_get(root, "errors") : nullptr;
    if (!json_is_array(errors) || json_array_size(errors) == 0)
        return;

    std::string message = "GFN GraphQL returned errors";
    json_t* first       = json_array_get(errors, 0);
    const std::string first_message = GetString(first, "message");
    if (!first_message.empty())
        message += ": " + first_message;

    throw std::runtime_error(message);
}

inline std::vector<GameInfo> ParseLibraryGames(JsonPtr& root)
{
    ThrowIfGraphQlFailed(root.get());

    std::unordered_map<std::string, size_t> index_by_id;
    std::vector<GameInfo> games;

    json_t* data   = json_object_get(root.get(), "data");
    json_t* panels = data ? json_object_get(data, "panels") : nullptr;
    if (!json_is_array(panels))
        throw std::runtime_error("Library response is missing data.panels");

    size_t total_items = 0;
    size_t invalid_games = 0;
    size_t panel_index = 0;
    json_t* panel      = nullptr;
    json_array_foreach(panels, panel_index, panel)
    {
        json_t* sections = json_object_get(panel, "sections");
        if (!json_is_array(sections))
            throw std::runtime_error("Library response is missing panel.sections");

        size_t section_index = 0;
        json_t* section      = nullptr;
        json_array_foreach(sections, section_index, section)
        {
            json_t* items = json_object_get(section, "items");
            if (!json_is_array(items))
                throw std::runtime_error("Library response is missing section.items");

            size_t item_index = 0;
            json_t* item      = nullptr;
            json_array_foreach(items, item_index, item)
            {
                ++total_items;
                if (GetString(item, "__typename") != "GameItem")
                    continue;

                json_t* app = json_object_get(item, "app");
                if (!json_is_object(app)) { ++invalid_games; continue; }

                GameInfo game = ParseApp(app);
                if (game.id.empty() || game.title.empty()) { ++invalid_games; continue; }

                const auto existing = index_by_id.find(game.id);
                if (existing == index_by_id.end())
                {
                    index_by_id.emplace(game.id, games.size());
                    games.push_back(std::move(game));
                }
                else
                {
                    MergeGame(games[existing->second], game);
                }
            }
        }
    }

    if (invalid_games != 0)
        throw std::runtime_error("Library contains unreadable game entries");
    if (games.empty() && total_items != 0)
        throw std::runtime_error("Library returned non-game items; empty library is unconfirmed");
    return games;
}

} // namespace opennow::gfn::detail
