$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$llvm = Join-Path $root 'tools/llvm-mingw-20260922-msvcrt-x86_64/llvm-mingw-20260922-msvcrt-x86_64'
$cmake = Join-Path $root 'tools/cmake-3.31.12/cmake-3.31.12-windows-x86_64/bin/cmake.exe'
$env:Path = "$llvm/bin;$llvm/busybox/bin;$env:Path"
$build = Join-Path $root 'build/host-jansson'
& $cmake -S "$root/src/third_party/jansson" -B $build -G 'MinGW Makefiles' `
    "-DCMAKE_MAKE_PROGRAM=$llvm/bin/mingw32-make.exe" `
    "-DCMAKE_C_COMPILER=$llvm/bin/clang.exe" `
    '-DJANSSON_BUILD_SHARED_LIBS=OFF' '-DJANSSON_EXAMPLES=OFF' `
    '-DJANSSON_BUILD_DOCS=OFF' '-DJANSSON_WITHOUT_TESTS=ON' '-DCMAKE_BUILD_TYPE=Release'
if ($LASTEXITCODE -ne 0) { throw 'Host Jansson configure failed' }
& $cmake --build $build --parallel 3
if ($LASTEXITCODE -ne 0) { throw 'Host Jansson build failed' }
$archive = @(Get-ChildItem $build -Recurse -Filter libjansson.a)
if ($archive.Count -ne 1) { throw 'Expected one Jansson archive' }
$exe = Join-Path $build 'library_response_test.exe'
& "$llvm/bin/clang++.exe" -std=c++20 -O1 -static -ffunction-sections -fdata-sections `
    '-Wl,--gc-sections' "-I$root/src/third_party/jansson/src" "-I$build/include" `
    "$root/tests/library_response_test.cpp" $archive[0].FullName -o $exe
if ($LASTEXITCODE -ne 0) { throw 'Library test compile failed' }
& $exe
if ($LASTEXITCODE -ne 0) { throw 'Library response regression failed' }
