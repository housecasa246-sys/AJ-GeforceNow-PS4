#include "../src/opennow/gfn/library_parser.hpp"
#include <cassert>
#include <iostream>

namespace opennow::gfn::detail {
std::string GetString(json_t* object, const char* key) {
    const char* value = json_string_value(json_object_get(object, key));
    return value ? value : "";
}
bool GetBool(json_t* object, const char* key, bool fallback) {
    json_t* value = json_object_get(object, key);
    return json_is_boolean(value) ? json_is_true(value) : fallback;
}
}

static size_t parse(const char* body) {
    json_error_t error{};
    opennow::gfn::detail::JsonPtr root(json_loads(body, 0, &error), &json_decref);
    if (!root) throw std::runtime_error("invalid JSON");
    return opennow::gfn::detail::ParseLibraryGames(root).size();
}
int main() {
    assert(parse(R"({"data":{"panels":[]}})") == 0);
    assert(parse(R"({"data":{"panels":[{"sections":[{"items":[]}]}]}})") == 0);
    const char* invalid[] = {
        R"({"data":null})", R"({"data":{"panels":{}}})",
        R"({"errors":[{"message":"PersistedQueryNotFound"}]})",
        R"({"data":{"panels":[{}]}})",
        R"({"data":{"panels":[{"sections":[{}]}]}})", "<html>blocked</html>"
    };
    const char* unreadable[] = {
        R"({"data":{"panels":[{"sections":[{"items":[{"__typename":"MessageItem"}]}]}]}})",
        R"({"data":{"panels":[{"sections":[{"items":[{"__typename":"GameItem"}]}]}]}})",
        R"({"data":{"panels":[{"sections":[{"items":[{"__typename":"GameItem","app":{"id":"1"}}]}]}]}})"
    };
    for (const char* body : unreadable) {
        bool rejected=false;
        try { parse(body); } catch (const std::exception&) { rejected=true; }
        assert(rejected);
    }
    for (const char* body : invalid) {
        bool rejected=false;
        try { parse(body); } catch (const std::exception&) { rejected=true; }
        assert(rejected);
    }
    assert(parse(R"({"data":{"panels":[{"sections":[{"items":[{"__typename":"GameItem","app":{"id":"123","title":"Test game","variants":[{"id":"456","appStore":"STEAM","gfn":{"library":{"status":"IN_LIBRARY","selected":true}}}]}}]}]}]}})") == 1);
    std::string large=R"({"data":{"panels":[{"sections":[{"items":[)";
    for (int i=0; i<1500; ++i) {
        if(i) large += ",";
        large += R"({"__typename":"GameItem","app":{"id":")" + std::to_string(i) +
            R"(","title":"Juego \u00f1 \ud83c\udfae","score":1.25,"nested":{"flags":[true,false,null],"exponent":1e-3},"description":")" +
            std::string(300,'x') + R"("}})";
    }
    large += R"(]}]}]}})";
    assert(large.size()>36280);
    for(int i=0;i<5;++i) assert(parse(large.c_str())==1500);
    std::cout << "12 regression checks and 5 large-library parsing cycles passed; bytes=" << large.size() << "\n";
}
