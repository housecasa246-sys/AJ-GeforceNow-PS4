#include "../src/opennow/community_proxy_policy.hpp"
#include "../src/opennow/catalog_result_policy.hpp"
#include <cassert>
#include <iostream>

int main()
{
    opennow::StreamSettings settings;
    settings.community_proxy_enabled = true;
    settings.community_proxy_url = "http://legacy:secret@old-proxy.invalid:3128";
    assert(opennow::community_proxy::EnabledUrl(settings).empty());
    assert(!opennow::community_proxy::IsCommunityProxyUrl(settings.community_proxy_url));
    using opennow::catalog_result::ErrorMessage;
    assert(ErrorMessage(200, -22).find("JSON") != std::string::npos);
    assert(ErrorMessage(200, -12).find("MEMORIA") != std::string::npos);
    assert(ErrorMessage(200, -1).find("HTTP 200") == std::string::npos);
    assert(ErrorMessage(403, -1).find("HTTP 403") != std::string::npos);
    assert(ErrorMessage(0, -7).find("-7") != std::string::npos);
    std::cout << "7 direct-connection/catalog policy checks passed\n";
}
