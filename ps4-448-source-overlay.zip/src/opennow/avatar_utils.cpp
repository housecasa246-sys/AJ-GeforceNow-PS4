#include "avatar_utils.hpp"

namespace opennow
{
std::string ResolveAvatarUrl(const AuthUser& user)
{
    return ResolveAvatarUrl(user.email, user.avatar_url);
}

std::string ResolveAvatarUrl(const std::string&, const std::string&)
{
    // The local placeholder avoids disclosing an email hash to an avatar service.
    return {};
}

} // namespace opennow
