$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$toolDir = Join-Path $root 'tools'
New-Item -ItemType Directory -Force $toolDir | Out-Null
# Official, versioned releases; record hashes in the build evidence.
$packages = @(
    @{Name='llvm'; Url='https://github.com/mstorsjo/llvm-mingw/releases/download/20260922/llvm-mingw-20260922-msvcrt-x86_64.zip'; Dest='llvm-mingw-20260922-msvcrt-x86_64'; Hash='1E936A4A694FC27F9625E3311F5EC5D6D99ABFEAA514FD41C52A4F8347145D1A'},
    @{Name='cmake'; Url='https://github.com/Kitware/CMake/releases/download/v3.31.12/cmake-3.31.12-windows-x86_64.zip'; Dest='cmake-3.31.12'; Hash='0C4BAA40F28B3F8225EB3FDF6946C987B4FE901403B4EAF2FBBD9378100AAA0C'},
    @{Name='openorbis'; Url='https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/releases/download/v0.5.3/toolchain-llvm-18.2.zip'; Dest='openorbis'; Hash='5006BB8629A40093B712FAC971456FA4D5AD3FAFAADB16D11C10B8A93B8B496F'}
)
foreach ($package in $packages) {
    $archive = Join-Path $toolDir ($package.Name + '.zip')
    if (-not (Test-Path $archive)) { Invoke-WebRequest $package.Url -OutFile $archive }
    $hash = Get-FileHash $archive -Algorithm SHA256
    if ($hash.Hash -ne $package.Hash) { throw "Checksum mismatch: $archive" }
    $hash | Format-List
    Expand-Archive $archive (Join-Path $toolDir $package.Dest) -Force
}
# The OpenOrbis ZIP contains the actual toolchain as a nested tar.gz.
$nested = Join-Path $toolDir 'openorbis/toolchain-llvm-18.tar.gz'
if (Test-Path $nested) {
    & tar -xf $nested -C (Join-Path $toolDir 'openorbis')
    if ($LASTEXITCODE -ne 0) { throw 'OpenOrbis extraction failed' }
}
$fself = @(Get-ChildItem (Join-Path $toolDir 'openorbis') -Recurse -Filter create-fself.exe)
if ($fself.Count -ne 1) { throw 'Expected exactly one OpenOrbis Windows toolchain' }
$env:OO_PS4_TOOLCHAIN = Split-Path -Parent (Split-Path -Parent $fself[0].DirectoryName)
$gitExe = (Get-Command git.exe -ErrorAction Stop).Source
$env:GFN_GIT_ROOT = Split-Path -Parent (Split-Path -Parent $gitExe)
foreach ($program in @('bash.exe')) {
    if (-not (Test-Path (Join-Path $env:GFN_GIT_ROOT "usr/bin/$program"))) {
        throw "Full Git for Windows is required (missing $program)"
    }
}
$env:GFN_PS4_HOST_PYTHON = (Get-Command python.exe -ErrorAction Stop).Source
if ($env:GITHUB_ENV) {
    "OO_PS4_TOOLCHAIN=$env:OO_PS4_TOOLCHAIN" | Out-File $env:GITHUB_ENV -Append -Encoding utf8
    "GFN_GIT_ROOT=$env:GFN_GIT_ROOT" | Out-File $env:GITHUB_ENV -Append -Encoding utf8
    "GFN_PS4_HOST_PYTHON=$env:GFN_PS4_HOST_PYTHON" | Out-File $env:GITHUB_ENV -Append -Encoding utf8
}
. (Join-Path $PSScriptRoot 'ps4-env.ps1')
